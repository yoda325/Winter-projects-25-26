# utils/test_eval.py
import numpy as np
import os
import torch

def measure_model_size(model_path):
    """Calculates the disk space taken by a saved model file in Megabytes (MB)."""
    size_bytes = os.path.getsize(model_path)
    size_mb = size_bytes / (1024 * 1024)
    print(f"File: {model_path}")
    print(f"Disk Space: {size_mb:.4f} MB")
    return size_mb

def measure_runtime_memory(device):
    """Prints a brief report of GPU memory usage if available."""
    if device.type == 'cuda':
        allocated = torch.cuda.memory_allocated(device) / (1024 * 1024)
        reserved = torch.cuda.memory_reserved(device) / (1024 * 1024)
        print(f"GPU Memory Allocated: {allocated:.2f} MB")
        print(f"GPU Memory Reserved:  {reserved:.2f} MB")
    elif device.type == 'mps':
        # Apple Silicon MPS doesn't expose memory stats exactly like CUDA yet
        print("Running on Apple Silicon (MPS). Open Activity Monitor to view unified memory usage.")
    else:
        print("Running on CPU. Standard RAM is being used.")